package com.sist.bbs_0220;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bbs0220Application {

	public static void main(String[] args) {
		SpringApplication.run(Bbs0220Application.class, args);
	}

}
