package com.sist.bbs_0220;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bbs0220ApplicationTests {

	@Test
	void contextLoads() {
	}

}
